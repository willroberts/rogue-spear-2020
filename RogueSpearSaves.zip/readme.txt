ROGUE SPEAR SAVE FILES

Unlocks all content in custom missions.

Renaming a save:
- Edit camp000N.cmp and change "RECRUIT", "VETERAN", or "ELITE" to your desired save name.

Installation:
- Copy to Rogue Spear\data\save (back up your saves first).